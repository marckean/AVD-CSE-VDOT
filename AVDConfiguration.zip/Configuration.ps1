configuration SetupSessionHost
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string]$storageConnectionString,

        [Parameter(Mandatory = $true)]
        [string]$HPtoken,

        [Parameter(Mandatory = $false)]
        [string]$signalExe = "signal-desktop-win-6.27.1.exe"
    )

    $ErrorActionPreference = 'Stop'
    
    #$ScriptPath = [system.io.path]::GetDirectoryName($pwd)
    $ScriptPath = (Get-ChildItem -Filter 'Setup-RDPSessionHosts.ps1' -Path "$env:SystemDrive\Packages" -Recurse).DirectoryName

    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode  = "ApplyOnly"
        }
        Script InstallSignal
        {
            TestScript = { # the TestScript block runs first. If the TestScript block returns $false, the SetScript block will run
                Test-Path "$env:ProgramFiles\signal-desktop"
            }
            SetScript = {
                $path = "$env:TEMP\SignalInstall"
                $exeName = $signalExe
                $exePath = "https://updates.signal.org/desktop/$exeName"
                Remove-Item "$path\$exeName" -Force -ErrorAction SilentlyContinue
                if (!(Test-Path $path)) { New-Item -Path $path -ItemType Directory }
                Start-BitsTransfer -Source $exePath -Destination $path
                Start-Process "$path\$exeName" -ArgumentList "/S" -wait
                # Find where Signal is installed and copy it to the Program Files folder
                $userProfiles = (Get-ChildItem -Path "$env:SystemDrive\Users")
                foreach ($userProfile in $userProfiles) {
                    if (Test-Path "$($userProfile.FullName)\AppData\Local\Programs\signal-desktop") {
                        Copy-Item -Path "$($userProfile.FullName)\AppData\Local\Programs\signal-desktop" -Destination "$env:ProgramFiles" -Recurse -Force
                        Break
                    }
                }
            }
            GetScript = { # should return a hashtable representing the state of the current node
            $result = Test-Path "$env:ProgramFiles\signal-desktop"
                @{
                    "Installed" = $result
                }
            } 
        }
        Script SetupSessionHost {
            TestScript = { # the TestScript block runs first. If the TestScript block returns $false, the SetScript block will run
                try {
                    # return (& "$using:ScriptPath\Setup-TestRDPSessionHosts.ps1")
                    $path = "HKLM:\SOFTWARE\FSLogix\Profiles"
                    $CCDLocations = (Get-Item $path).Property | where {$_ -eq 'CCDLocations'}
                    if($CCDLocations -eq 'CCDLocations'){return $true} else {return $false;}
                }
                catch {
                    $ErrMsg = $PSItem | Format-List -Force | Out-String
                    throw [System.Exception]::new("Some error occurred in Session Host setup script: $ErrMsg", $PSItem.Exception)
                }
            }
            SetScript  = {
                try {
                    & "$using:ScriptPath\Setup-RDPSessionHosts.ps1" -storageConnectionString $using:storageConnectionString -HPtoken $using:HPtoken
                }
                catch {
                    $ErrMsg = $PSItem | Format-List -Force | Out-String
                    throw [System.Exception]::new("Some error occurred in Session Host setup script: $ErrMsg", $PSItem.Exception)
                }
            }
            GetScript  = {
                $path = "HKLM:\SOFTWARE\FSLogix\Profiles"
                $CCDLocations = (Get-Item $path).Property | where {$_ -eq 'CCDLocations'}
                if($CCDLocations -eq 'CCDLocations'){return $true} else {return $false;}
            } 
            }
            DependsOn = "[Script]InstallSignal"
        }
    }
}