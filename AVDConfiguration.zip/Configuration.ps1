configuration SetupSessionHost
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string]$storageConnectionString = 'DefaultEndpointsProtocol=https;AccountName=20230710afpstg;AccountKey=RGxWBYsmFdGp7RhGeET2+X67T/cz3xno28CnTy2E6yeraSPMVr87ehYIoIsWHhD84lWToRVRAK1S+ASteV2Nzg==;EndpointSuffix=core.windows.net',

        [Parameter(Mandatory = $true)]
        [string]$HPtoken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ4Q0Y2MjhENTM5OUYzNTMwQkM5MzI0RjgyMzVFNEY1RkEyOTQxNkIiLCJ0eXAiOiJKV1QifQ.eyJSZWdpc3RyYXRpb25JZCI6IjdmNjE1OTc0LTA4ZjQtNDMyNi04MWZhLTJjYTE1ZTY0NGFmNiIsIkJyb2tlclVyaSI6Imh0dHBzOi8vcmRicm9rZXItZy1hdS1yMC53dmQubWljcm9zb2Z0LmNvbS8iLCJEaWFnbm9zdGljc1VyaSI6Imh0dHBzOi8vcmRkaWFnbm9zdGljcy1nLWF1LXIwLnd2ZC5taWNyb3NvZnQuY29tLyIsIkVuZHBvaW50UG9vbElkIjoiYjJjMDQzMWItMjcwMC00YmE0LWE4ZWEtMjkzZDRhYWVmMzhhIiwiR2xvYmFsQnJva2VyVXJpIjoiaHR0cHM6Ly9yZGJyb2tlci53dmQubWljcm9zb2Z0LmNvbS8iLCJHZW9ncmFwaHkiOiJBVSIsIkdsb2JhbEJyb2tlclJlc291cmNlSWRVcmkiOiJodHRwczovL2IyYzA0MzFiLTI3MDAtNGJhNC1hOGVhLTI5M2Q0YWFlZjM4YS5yZGJyb2tlci53dmQubWljcm9zb2Z0LmNvbS8iLCJCcm9rZXJSZXNvdXJjZUlkVXJpIjoiaHR0cHM6Ly9iMmMwNDMxYi0yNzAwLTRiYTQtYThlYS0yOTNkNGFhZWYzOGEucmRicm9rZXItZy1hdS1yMC53dmQubWljcm9zb2Z0LmNvbS8iLCJEaWFnbm9zdGljc1Jlc291cmNlSWRVcmkiOiJodHRwczovL2IyYzA0MzFiLTI3MDAtNGJhNC1hOGVhLTI5M2Q0YWFlZjM4YS5yZGRpYWdub3N0aWNzLWctYXUtcjAud3ZkLm1pY3Jvc29mdC5jb20vIiwiQUFEVGVuYW50SWQiOiIyN2ZjZDBkNi04YzI0LTQzMDQtOWE2Yi1lMGZkZTY4MzAzNTQiLCJuYmYiOjE2OTExMjYzMDksImV4cCI6MTY5MTE1NTEwNywiaXNzIjoiUkRJbmZyYVRva2VuTWFuYWdlciIsImF1ZCI6IlJEbWkifQ.OzR-cMPvVkr_hyJ7nSDvX9FpEdjEC7cw21LJiYjyp8h6UKDqor01AG9fVSix0v6iukCvoE0qZZI_ZL324LddvQ_Auc9dWx3vzwmioNqUv1d6odjccMlwlREhiJPm5fXdGrLgv-QAMGrkQ8GVl7Cel1ejsfSngsEbnC6uWtuxc0Xpkalih2T8HIli-XNHZep3jksBQ1bPFjAx-DZy_q5RRALAzcOhr-5zpyv1LSViuMXfCryRE2XpWyRDPF_vOJChAikX5S4nAeF9O2FrPwpCUT1innJrigN26uI4h1fUmuIfoxcx3I-_cpbW3nUZSGJCakIpR4wxAwxkuM3ruuayDA'
    )

    $ErrorActionPreference = 'Stop'
    
    #$ScriptPath = [system.io.path]::GetDirectoryName($pwd)
    $ScriptPath = (Get-ChildItem -Filter 'Setup-RDPSessionHosts.ps1' -Path "$env:SystemDrive\Packages" -Recurse).DirectoryName

    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode  = "ApplyOnly"
        }

        Script SetupSessionHost {
            GetScript  = {
                return @{'Result' = '' }
            }
            SetScript  = {
                try {
                    & "$using:ScriptPath\Setup-RDPSessionHosts.ps1" -storageConnectionString $using:storageConnectionString -HPtoken $using:HPtoken
                }
                catch {
                    $ErrMsg = $PSItem | Format-List -Force | Out-String
                    throw [System.Exception]::new("Some error occurred in Session Host setup script: $ErrMsg", $PSItem.Exception)
                }
            }
            TestScript = {
                try {
                    return (& "$using:ScriptPath\Setup-TestRDPSessionHosts.ps1")
                }
                catch {
                    $ErrMsg = $PSItem | Format-List -Force | Out-String
                    throw [System.Exception]::new("Some error occurred in Session Host setup script: $ErrMsg", $PSItem.Exception)
                }

            }
        }
    }
}