configuration SetupSessionHost
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string]$storageConnectionString,

        [Parameter(Mandatory = $true)]
        [string]$HPtoken
    )

    $ErrorActionPreference = 'Stop'
    
    #$ScriptPath = [system.io.path]::GetDirectoryName($pwd)
    $ScriptPath = (Get-ChildItem -Filter 'Setup-RDPSessionHosts.ps1' -Path "$env:SystemDrive\Packages" -Recurse).DirectoryName

    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode  = "ApplyOnly"
        }

        Script SetupSessionHost {
            GetScript  = {
                return @{'Result' = '' }
            }
            SetScript  = {
                try {
                    & "$using:ScriptPath\Setup-RDPSessionHosts.ps1" -storageConnectionString $using:HostPoolName -HPtoken $using:RegistrationInfoToken
                }
                catch {
                    $ErrMsg = $PSItem | Format-List -Force | Out-String
                    throw [System.Exception]::new("Some error occurred in Session Host setup script: $ErrMsg", $PSItem.Exception)
                }
            }
            TestScript = {
                try {
                    return (& "$using:ScriptPath\Setup-TestRDPSessionHosts.ps1")
                }
                catch {
                    $ErrMsg = $PSItem | Format-List -Force | Out-String
                    throw [System.Exception]::new("Some error occurred in Session Host setup script: $ErrMsg", $PSItem.Exception)
                }

            }
        }
    }
}