

##############################################################
#  Install Signal
##############################################################
$path = "$env:ProgramFiles\signal-desktop"

if(Test-Path $path){return $true} else {return $false;}
